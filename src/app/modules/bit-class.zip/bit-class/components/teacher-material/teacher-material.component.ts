import { Component } from '@angular/core';

@Component({
  selector: 'app-teacher-material',
  imports: [],
  templateUrl: './teacher-material.component.html',
  styleUrl: './teacher-material.component.scss'
})
export class TeacherMaterialComponent {

}

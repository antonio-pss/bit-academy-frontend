import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClassBestStudentsComponent } from './class-best-students.component';

describe('ClassBestStudentsComponent', () => {
  let component: ClassBestStudentsComponent;
  let fixture: ComponentFixture<ClassBestStudentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ClassBestStudentsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ClassBestStudentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClassMiniStudentsComponent } from './class-mini-students.component';

describe('ClassMiniStudentsComponent', () => {
  let component: ClassMiniStudentsComponent;
  let fixture: ComponentFixture<ClassMiniStudentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ClassMiniStudentsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ClassMiniStudentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

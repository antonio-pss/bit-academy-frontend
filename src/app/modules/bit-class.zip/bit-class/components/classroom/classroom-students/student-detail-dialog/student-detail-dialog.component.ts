import { Component } from '@angular/core';

@Component({
  selector: 'app-student-detail-dialog',
  imports: [],
  templateUrl: './student-detail-dialog.component.html',
  styleUrl: './student-detail-dialog.component.scss'
})
export class StudentDetailDialogComponent {

}

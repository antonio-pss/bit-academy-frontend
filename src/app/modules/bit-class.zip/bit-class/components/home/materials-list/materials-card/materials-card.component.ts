import { Component } from '@angular/core';

@Component({
  selector: 'app-materials-card',
  imports: [],
  templateUrl: './materials-card.component.html',
  styleUrl: './materials-card.component.scss'
})
export class MaterialsCardComponent {

}
